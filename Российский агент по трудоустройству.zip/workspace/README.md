# وكيل البحث عن عمل في روسيا

وكيل ويب يبحث عن وظائف في المنصات الروسية حسب ملفك المهني.

## المصادر

- hh.ru (HeadHunter API)
- Работа России (opendata.trudvsem.ru)

## التشغيل

```bash
cd backend
npm install

cd ../frontend
npm install
npm run dev
```

الخادم الخلفي على المنفذ 3001، والواجهة على 5173 مع وكيل عكسي لمسار `/api`.
