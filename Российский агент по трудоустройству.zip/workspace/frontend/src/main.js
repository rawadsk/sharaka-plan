const form = document.getElementById('profile-form')
const jobsEl = document.getElementById('jobs')
const adviceEl = document.getElementById('advice')
const metaEl = document.getElementById('meta')
const statusEl = document.getElementById('status')
const btn = document.getElementById('search-btn')

function payloadFromForm(fd) {
  const keywords = String(fd.get('keywords') || '')
    .split(/[,،]/)
    .map((s) => s.trim())
    .filter(Boolean)
  return {
    title: fd.get('title'),
    skills: fd.get('skills'),
    city: fd.get('city'),
    minSalary: fd.get('minSalary') ? Number(fd.get('minSalary')) : null,
    experience: fd.get('experience') || '',
    remote: fd.get('remote') === 'on',
    keywords,
    language: 'ar'
  }
}

function escapeHtml(s) {
  return String(s || '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
}

function jobCard(job) {
  const sourceClass = job.source === 'hh.ru' ? 'hh' : 'trudvsem'
  return `
    <article class="card">
      <div class="card-top">
        <div>
          <h3>${escapeHtml(job.title)}</h3>
          <div class="company">${escapeHtml(job.company)} · ${escapeHtml(job.city)}</div>
        </div>
        <div class="score">تطابق ${job.score}%</div>
      </div>
      <div class="tags">
        <span class="tag ${sourceClass}">${escapeHtml(job.sourceLabel)}</span>
        ${job.remote ? '<span class="tag remote">عن بُعد</span>' : ''}
        ${job.salary ? `<span class="tag">${escapeHtml(job.salary)}</span>` : '<span class="tag">راتب غير معلن</span>'}
      </div>
      ${job.snippet ? `<p class="snippet">${escapeHtml(job.snippet).slice(0, 280)}</p>` : ''}
      <a href="${escapeHtml(job.url)}" target="_blank" rel="noopener noreferrer">فتح الإعلان والتقديم</a>
    </article>
  `
}

form.addEventListener('submit', async (e) => {
  e.preventDefault()
  btn.disabled = true
  statusEl.textContent = 'الوكيل يبحث الآن...'
  jobsEl.classList.remove('empty')
  jobsEl.innerHTML = 'جاري جلب الوظائف من hh.ru وРабота России...'
  adviceEl.innerHTML = ''
  metaEl.textContent = ''

  try {
    const res = await fetch('/api/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payloadFromForm(new FormData(form)))
    })
    const data = await res.json()
    if (!res.ok) throw new Error(data.message || 'search_failed')

    const portalHtml = (data.portals || []).map((p) =>
      `<li>افتح أيضاً: <a class="portal" href="${escapeHtml(p.url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(p.name)}</a></li>`
    ).join('')
    adviceEl.innerHTML = portalHtml + (data.advice || []).map((a) => `<li>${escapeHtml(a)}</li>`).join('')
    metaEl.textContent = `${data.total} وظيفة · ${data.queryRu || ''} · ${data.tookMs}ms`
    if (!data.jobs?.length) {
      jobsEl.classList.add('empty')
      jobsEl.textContent = 'لا توجد نتائج مطابقة. غيّر المسمى أو المدينة أو ألغِ فلتر العمل عن بُعد.'
    } else {
      jobsEl.innerHTML = data.jobs.map(jobCard).join('')
    }
    statusEl.textContent = data.sources?.hh === 'ok' ? 'تم البحث بنجاح' : 'اكتمل مع تحذيرات من مصدر'
  } catch (err) {
    jobsEl.classList.add('empty')
    jobsEl.textContent = 'تعذر الاتصال بالوكيل. تأكد أن الخادم الخلفي يعمل.'
    statusEl.textContent = 'فشل البحث'
    console.error(err)
  } finally {
    btn.disabled = false
  }
})
