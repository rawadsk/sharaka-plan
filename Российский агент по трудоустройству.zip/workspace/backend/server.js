import express from 'express'
import cors from 'cors'

const app = express()
const PORT = 3001
const HH_BASE = 'https://api.hh.ru'
const TRUD_BASE = 'https://opendata.trudvsem.ru/api/v1/vacancies'

app.use(cors())
app.use(express.json({ limit: '1mb' }))

const TITLE_RU = [
  [/frontend|front-end|react|vue|angular|فرونت/i, 'фронтенд разработчик'],
  [/backend|back-end|node|django|spring|باكند/i, 'бэкенд разработчик'],
  [/fullstack|full-stack|فل ستاك/i, 'fullstack разработчик'],
  [/mobile|android|ios|flutter|kotlin|موبايل/i, 'мобильный разработчик'],
  [/devops|sre|kubernetes|docker/i, 'devops инженер'],
  [/data scientist|machine learning|ml engineer|ai engineer/i, 'специалист по машинному обучению'],
  [/data analyst|аналитик|محلل/i, 'аналитик данных'],
  [/qa|test engineer|тестир|اختبار/i, 'тестировщик'],
  [/product manager|продакт|مدير منتج/i, 'менеджер продукта'],
  [/project manager|менеджер проект|مدير مشروع/i, 'проектный менеджер'],
  [/ui|ux|designer|дизайнер|مصمم/i, 'дизайнер'],
  [/marketing|smm|تسويق|مسوق/i, 'маркетолог'],
  [/sales| продаж|مبيعات/i, 'менеджер по продажам'],
  [/support|helpdesk|دعم/i, 'специалист технической поддержки'],
  [/translator|перевод|مترجم|arabic|arab|عربي/i, 'переводчик арабского языка'],
  [/teacher|преподаватель|معلم|مدرس/i, 'преподаватель'],
  [/accountant|бухгалтер|محاسب/i, 'бухгалтер'],
  [/hr |recruiter|кадр|موارد بشرية/i, 'hr менеджер'],
  [/developer|engineer|programmer|программист|مطور|مهندس/i, 'разработчик программист']
]

const ROLE_KEYWORDS = {
  developer: ['разработчик', 'программист', 'developer', 'engineer', 'frontend', 'backend', 'fullstack'],
  frontend: ['frontend', 'front-end', 'фронтенд', 'верстальщик', 'react', 'vue', 'javascript'],
  backend: ['backend', 'back-end', 'бэкенд', 'python', 'java', 'go', 'node'],
  data: ['data scientist', 'аналитик данных', 'machine learning', 'ml engineer', 'дата'],
  design: ['дизайнер', 'designer', 'ux', 'ui', 'figma'],
  product: ['product manager', 'продакт', 'менеджер продукта', 'pm'],
  marketing: ['маркетолог', 'marketing', 'smm', 'контент'],
  sales: ['продажи', 'sales', 'менеджер по продажам', 'account'],
  support: ['поддержка', 'support', 'helpdesk', 'customer success'],
  qa: ['qa', 'тестировщик', 'quality assurance', 'sdet'],
  devops: ['devops', 'sre', 'kubernetes', 'docker', 'инфраструктура'],
  translator: ['переводчик', 'translator', 'арабский', 'arabic', 'english'],
  teacher: ['преподаватель', 'учитель', 'teacher', 'репетитор'],
  manager: ['менеджер', 'руководитель', 'manager', 'директор']
}

const CITY_MAP = {
  moscow: { id: '1', name: 'Москва', regionCode: '7700000000000', aliases: ['moscow', 'москва', 'msk'] },
  spb: { id: '2', name: 'Санкт-Петербург', regionCode: '7800000000000', aliases: ['spb', 'saint petersburg', 'санкт-петербург', 'питер'] },
  kazan: { id: '88', name: 'Казань', regionCode: '1600000000000', aliases: ['kazan', 'казань'] },
  novosibirsk: { id: '4', name: 'Новосибирск', regionCode: '5400000000000', aliases: ['novosibirsk', 'новосибирск'] },
  yekaterinburg: { id: '3', name: 'Екатеринбург', regionCode: '6600000000000', aliases: ['yekaterinburg', 'екатеринбург'] },
  nizhny: { id: '66', name: 'Нижний Новгород', regionCode: '5200000000000', aliases: ['nizhny', 'нижний'] },
  krasnodar: { id: '53', name: 'Краснодар', regionCode: '2300000000000', aliases: ['krasnodar', 'краснодар'] },
  remote: { id: null, name: 'Удалённо', regionCode: null, aliases: ['remote', 'удален'] }
}

function normalize(text) {
  return String(text || '').toLowerCase().trim()
}

function detectCity(text) {
  const n = normalize(text)
  for (const city of Object.values(CITY_MAP)) {
    if (city.aliases.some((a) => n.includes(a))) return city
  }
  return null
}

function toRussianQuery(profile) {
  const blob = [profile.title, profile.skills, ...(profile.keywords || [])].filter(Boolean).join(' ')
  for (const [re, ru] of TITLE_RU) {
    if (re.test(blob)) return ru
  }
  return profile.title || 'работа'
}

function searchTerms(profile) {
  const terms = new Set()
  terms.add(toRussianQuery(profile))
  if (profile.title) terms.add(String(profile.title).trim())
  for (const k of profile.keywords || []) {
    if (k && String(k).trim().length > 1) terms.add(String(k).trim())
  }
  const skills = String(profile.skills || '').split(/[,،]/).map((s) => s.trim()).filter((s) => s.length > 2)
  skills.slice(0, 2).forEach((s) => terms.add(s))
  return [...terms].slice(0, 4)
}

function detectRoleKeywords(profile) {
  const blob = normalize([
    profile.title,
    profile.skills,
    profile.bio,
    ...(profile.keywords || [])
  ].join(' '))
  const found = new Set()
  for (const words of Object.values(ROLE_KEYWORDS)) {
    if (words.some((w) => blob.includes(w))) {
      words.slice(0, 3).forEach((w) => found.add(w))
    }
  }
  if (profile.title) found.add(profile.title)
  found.add(toRussianQuery(profile))
  if (Array.isArray(profile.keywords)) profile.keywords.forEach((k) => found.add(k))
  return [...found].filter(Boolean).slice(0, 6)
}

function salaryText(salary) {
  if (!salary) return null
  const from = salary.from
  const to = salary.to
  const cur = salary.currency === 'RUR' ? '₽' : salary.currency || '₽'
  if (from && to) return `${from.toLocaleString('ru-RU')} – ${to.toLocaleString('ru-RU')} ${cur}`
  if (from) return `от ${from.toLocaleString('ru-RU')} ${cur}`
  if (to) return `до ${to.toLocaleString('ru-RU')} ${cur}`
  return null
}

function matchScore(job, profile) {
  const hay = normalize(`${job.title} ${job.company} ${job.snippet || ''} ${job.requirement || ''}`)
  const needles = [
    profile.title,
    ...(profile.skills || '').split(/[,،]/),
    ...(profile.keywords || [])
  ].map(normalize).filter((s) => s.length > 1)

  if (!needles.length) return 55
  let hits = 0
  for (const n of needles) {
    if (hay.includes(n)) hits += 1
  }
  let score = Math.round(40 + (hits / Math.max(needles.length, 1)) * 50)
  const ru = toRussianQuery(profile)
  if (ru && hay.includes(normalize(ru.split(' ')[0]))) score = Math.min(99, score + 10)
  const city = detectCity(profile.city || '')
  if (city && normalize(job.city).includes(normalize(city.name).split(' ')[0])) {
    score = Math.min(99, score + 8)
  }
  if (profile.remote && job.remote) score = Math.min(99, score + 8)
  if (profile.minSalary && job.salaryFrom && job.salaryFrom >= Number(profile.minSalary)) {
    score = Math.min(99, score + 6)
  }
  return Math.max(38, Math.min(99, score))
}

async function fetchJson(url, headers = {}) {
  const res = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (compatible; RabotaAgent/1.0; +https://trudvsem.ru)',
      Accept: 'application/json',
      ...headers
    }
  })
  if (!res.ok) {
    const body = await res.text().catch(() => '')
    throw new Error(`HTTP ${res.status} ${url} ${body.slice(0, 120)}`)
  }
  return res.json()
}

function hhSearchUrl(profile) {
  const params = new URLSearchParams()
  params.set('text', toRussianQuery(profile))
  const city = detectCity(profile.city || '')
  if (city?.id) params.set('area', city.id)
  if (profile.remote) params.set('schedule', 'remote')
  if (profile.minSalary) params.set('salary', String(profile.minSalary))
  return `https://hh.ru/search/vacancy?${params.toString()}`
}

function mapHhItem(item) {
  const snippet = [item.snippet?.requirement, item.snippet?.responsibility].filter(Boolean).join(' ')
  return {
    id: `hh-${item.id}`,
    source: 'hh.ru',
    sourceLabel: 'HeadHunter',
    title: item.name,
    company: item.employer?.name || '—',
    city: item.area?.name || '—',
    remote: item.schedule?.id === 'remote' || /удал/i.test(item.schedule?.name || ''),
    salary: salaryText(item.salary),
    salaryFrom: item.salary?.from || null,
    url: item.alternate_url,
    publishedAt: item.published_at,
    snippet,
    requirement: item.snippet?.requirement || '',
    logo: item.employer?.logo_urls?.['90'] || null
  }
}

async function searchHh(profile, page = 0) {
  const params = new URLSearchParams()
  params.set('text', toRussianQuery(profile))
  params.set('per_page', '20')
  params.set('page', String(page))
  params.set('order_by', 'relevance')

  const city = detectCity(profile.city || '')
  if (city?.id) params.set('area', city.id)
  if (profile.remote) params.set('schedule', 'remote')
  if (profile.minSalary) params.set('salary', String(profile.minSalary))
  if (profile.experience === 'noExperience') params.set('experience', 'noExperience')
  if (profile.experience === 'between1And3') params.set('experience', 'between1And3')
  if (profile.experience === 'between3And6') params.set('experience', 'between3And6')
  if (profile.experience === 'moreThan6') params.set('experience', 'moreThan6')

  const data = await fetchJson(`${HH_BASE}/vacancies?${params.toString()}`, {
    'HH-User-Agent': 'RabotaAgent/1.0 (jobs-agent@example.com)'
  })
  return (data.items || []).map(mapHhItem)
}

function mapTrudVacancy(v, city) {
  const title = v['job-name'] || v.job_name || v.vacancy_name || v.title || 'Вакансия'
  const salaryFrom = Number(v.salary_min) || null
  const salaryTo = Number(v.salary_max) || null
  const addr = v.addresses?.address
  const loc = Array.isArray(addr) ? addr[0]?.location : addr?.location
  const reqText = typeof v.requirement === 'string'
    ? v.requirement
    : [v.requirements, v.qualification].filter(Boolean).join(' ')
  return {
    id: `tv-${v.id || Math.random().toString(36).slice(2)}`,
    source: 'trudvsem',
    sourceLabel: 'Работа России',
    title,
    company: v.company?.name || '—',
    city: loc || v.region?.name || city?.name || '—',
    remote: /удал|дистанц/i.test(`${v.schedule || ''} ${title} ${v.employment || ''}`),
    salary: salaryText({ from: salaryFrom, to: salaryTo && salaryTo !== salaryFrom ? salaryTo : null, currency: 'RUR' })
      || (v.salary && v.salary !== 'false' ? String(v.salary) : null),
    salaryFrom,
    url: v.vac_url || 'https://trudvsem.ru',
    publishedAt: v['creation-date'] || v.date_modify || null,
    snippet: [v.duty, reqText].filter(Boolean).join(' ').slice(0, 400),
    requirement: reqText || '',
    logo: null
  }
}

async function searchTrudvsem(profile) {
  const city = detectCity(profile.city || '')
  const terms = searchTerms(profile)
  const collected = []
  const seen = new Set()

  for (const term of terms) {
    const params = new URLSearchParams()
    params.set('text', term)
    params.set('offset', '0')
    params.set('limit', '25')
    const url = `${TRUD_BASE}?${params.toString()}`
    try {
      const data = await fetchJson(url)
      const results = data?.results?.vacancies || []
      for (const row of results) {
        const job = mapTrudVacancy(row.vacancy || row, city)
        if (seen.has(job.id)) continue
        seen.add(job.id)
        collected.push(job)
      }
    } catch {
      continue
    }
    if (collected.length >= 40) break
  }

  return collected.filter((job) => {
    if (profile.remote && !job.remote) return false
    if (profile.minSalary && job.salaryFrom && job.salaryFrom < Number(profile.minSalary) * 0.4) {
      return false
    }
    return true
  })
}

function buildAdvice(profile, jobs) {
  const advice = []
  if (!profile.title) advice.push('حدد المسمى الوظيفي بوضوح (مثلاً Frontend Developer أو مترجم عربي-روسي).')
  if (!profile.city && !profile.remote) advice.push('اختر مدينة روسية أو فعّل العمل عن بُعد لتوسيع النتائج.')
  advice.push(`ابحث على hh.ru بهذه الصياغة الروسية: ${toRussianQuery(profile)}.`)
  if (!jobs.length) {
    advice.push('جرّب كلمات روسية شائعة: разработчик، дизайнер، маркетолог، переводчик.')
    advice.push('منصتا SuperJob وHabr Career مفيدتان لتقنية المعلومات إذا كان hh.ru محجوباً من شبكتك.')
  }
  const remoteCount = jobs.filter((j) => j.remote).length
  if (profile.remote && remoteCount === 0 && jobs.length) {
    advice.push('لا توجد وظائف عن بُعد مطابقة الآن. ألغِ فلتر العمل عن بُعد أو أضف مدناً مثل موسكو وسانت بطرسبرغ.')
  }
  if (jobs.length && jobs.every((j) => !j.salary)) {
    advice.push('كثير من الشركات الروسية لا تعلن الراتب. يمكنك التفاوض بعد المقابلة.')
  }
  if (profile.language === 'ar' || /arab|عربي/i.test(`${profile.title} ${profile.skills}`)) {
    advice.push('للناطقين بالعربية: ابحث أيضاً عن переводчик арабского و менеджер по работе с MENA.')
  }
  advice.push('جهّز سيرة ذاتية بالروسية أو الإنجليزية، وافتح حساباً على hh.ru لتقديم الطلب مباشرة.')
  return advice.slice(0, 5)
}

app.get('/api/health', (_req, res) => {
  res.json({ ok: true })
})

app.get('/api/cities', (_req, res) => {
  res.json(Object.values(CITY_MAP).map((c) => ({ name: c.name, aliases: c.aliases })))
})

app.post('/api/search', async (req, res) => {
  const profile = req.body || {}
  const started = Date.now()
  try {
    const [hh, trud] = await Promise.allSettled([
      searchHh(profile),
      searchTrudvsem(profile)
    ])
    const hhJobs = hh.status === 'fulfilled' ? hh.value : []
    const trudJobs = trud.status === 'fulfilled' ? trud.value : []
    const sources = {
      hh: hh.status === 'fulfilled' ? 'ok' : String(hh.reason?.message || hh.reason),
      trudvsem: trud.status === 'fulfilled' ? 'ok' : String(trud.reason?.message || trud.reason)
    }

    const merged = [...hhJobs, ...trudJobs]
    const seen = new Set()
    const unique = merged.filter((j) => {
      const key = `${normalize(j.title)}|${normalize(j.company)}`
      if (seen.has(key)) return false
      seen.add(key)
      return true
    })

    const jobs = unique
      .map((job) => ({ ...job, score: matchScore(job, profile) }))
      .sort((a, b) => b.score - a.score)
      .slice(0, 40)

    const keywords = detectRoleKeywords(profile)
    const portals = [
      { name: 'HeadHunter', url: hhSearchUrl(profile) },
      { name: 'Работа России', url: `https://trudvsem.ru/vacancy/search?title=${encodeURIComponent(toRussianQuery(profile))}` },
      { name: 'Habr Career', url: `https://career.habr.com/vacancies?q=${encodeURIComponent(profile.title || toRussianQuery(profile))}` }
    ]
    res.json({
      jobs,
      total: jobs.length,
      keywords,
      queryRu: toRussianQuery(profile),
      portals,
      advice: buildAdvice(profile, jobs),
      sources,
      tookMs: Date.now() - started
    })
  } catch (err) {
    res.status(500).json({ error: 'search_failed', message: String(err.message || err) })
  }
})

app.listen(PORT, '0.0.0.0', () => {
  console.log(`job-agent backend on ${PORT}`)
})
